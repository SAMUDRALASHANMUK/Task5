package com.marketsimplified;

import java.io.BufferedReader;
import java.io.IOException;
//import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;


//import prefilledData.TableData;
@WebServlet("/Response")
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//PreFilled HashTable's Data
		
		Employee emp1 = new Employee(100,"shanmuk","Java", 300000);
		Employee emp2 = new Employee(101,"shan","Human-Resource", 40000);
		Employee emp3 = new Employee(102,"shannu","Graphic-Designer", 50000);
		Employee emp4 = new Employee(103,"mouniker","Art-Music", 30000);
		Employee emp5 = new Employee(104,"mujafar","Java", 60000);
		Employee emp6 = new Employee(105,"narasimha","DataBase", 50000);
		Employee emp7 = new Employee(106,"srehitha","Testing", 100000);
		Employee emp8 = new Employee(107,"jasmin","Developer", 90000);
		Hashtable<Integer, Employee> data = new Hashtable<>();
		data.put(emp1.empcode, emp1);
		data.put(emp2.empcode, emp2);
		data.put(emp3.empcode, emp3);
		data.put(emp4.empcode, emp4);
		data.put(emp5.empcode, emp5);
		data.put(emp6.empcode, emp6);
		data.put(emp7.empcode, emp7);
		data.put(emp8.empcode, emp8);
		
		PrintWriter out = response.getWriter();
		//Business Logic Part
		
		String contenttype= request.getContentType();
		//System.out.println(contenttype);
		if(contenttype.equals("application/json")) {
			
			response.setContentType("application/json");
			StringBuffer jb= new StringBuffer();
			String line=null;
			BufferedReader reader=request.getReader();
			while((line=reader.readLine())!= null) 
			{
				jb.append(line);
				
			}
			JSONObject jsobj = new JSONObject(jb.toString());
			int empcode=jsobj.getInt("empcode");
			JSONObject tabledata= new JSONObject();
			if(data.containsKey(empcode)) {
				
			tabledata.put("EmpCode",data.get(empcode).empcode );
			tabledata.put("Name", data.get(empcode).name);
			tabledata.put("Department", data.get(empcode).department);
			tabledata.put("Salary", data.get(empcode).salary);
				
			}else {
				out.println("Entered Invalid Id, Kindly Check It.");
			}
			out.print(tabledata);
			System.out.println(tabledata);
			
		}else {
			out.println("Try Again...");
		}
	}

}