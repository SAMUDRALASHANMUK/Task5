package com.marketsimplified;

public class Employee
{

	public int empcode;
		public String name;
		public String department;
		public double salary;
			public Employee(int empcode, String name, String department, double salary) {
			super();
			this.empcode = empcode;
			this.name = name;
			this.department = department;
			this.salary = salary;
		}
			@Override
			public String toString() {
				return "  " + empcode + " "+ name + " " + department + " " + salary
						+ " ";
			}
			
}
